# 1. 定义一个变量记录 QQ 号码
qq_number = "1234567"

# 2. 定义一个变量记录 QQ 密码
qq_password = "123"

# 注意：在使用解释器执行 python 程序的时候，不能直接使用变量名
# 在控制台输出变量的信息
qq_number

# 如果希望通过解释器的方式，输出变量的内容，需要使用 print 函数
print(qq_number)
print(qq_password)
