li = [1, 2, 3, 4]
while len(li) > 0:
    li.pop()
print(li)